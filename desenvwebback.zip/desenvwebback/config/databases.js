module.exports = {
    blog: {
        username: 'postgres',
        port: '5432',
        password: 'postgres',
        database: 'blog',
        host: '127.0.0.1',
        dialect: 'postgres',
        logging: false,
    }
}